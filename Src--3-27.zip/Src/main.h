


#include "DF.h"
#include "Function.h"
#include "Hareware.h" 


#define  true    1
#define  false   0

typedef  unsigned int          u32;
typedef  unsigned short        u16;
typedef  unsigned char         u8;




